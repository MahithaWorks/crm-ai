import { useState } from "react";
import Sidebar from "../components/Sidebar";
import { leadsData, addLeadToStore } from "../data/store";
import { motion } from "framer-motion";

function Leads() {
  const [, setRefresh] = useState(false);

  const [name, setName] = useState("");
  const [budget, setBudget] = useState("");
  const [agent, setAgent] = useState("Agent A");

  const user = JSON.parse(localStorage.getItem("loggedInUser"));

  const addLead = () => {
    if (!name || !budget) return;

    const score =
      budget > 10000 ? "High" : budget > 5000 ? "Medium" : "Low";

    const newLead = {
      id: Date.now(),
      name,
      budget,
      score,
      agent,
      owner: user?.username, // ✅ USER LINK
      status: "New",
    };

    addLeadToStore(newLead);
    setRefresh((prev) => !prev);

    setName("");
    setBudget("");
    setAgent("Agent A");
  };

  // ✅ FILTER LEADS BY USER
  const myLeads = leadsData.filter(
    (lead) => lead.owner === user?.username
  );

  return (
    <div className="flex">
      <Sidebar />

      <div className="p-8 w-full">
        <h1 className="text-3xl font-bold mb-6">Leads</h1>

        {/* FORM */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-[#1a1a2e] p-6 rounded-xl mb-6 shadow-lg"
        >
          <h2 className="mb-4 text-purple-300">Add New Lead</h2>

          <div className="flex gap-4 flex-wrap">
            <input
              className="p-2 rounded bg-[#111122] border border-gray-700 text-white"
              placeholder="Customer Name"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />

            <input
              className="p-2 rounded bg-[#111122] border border-gray-700 text-white"
              placeholder="Budget"
              value={budget}
              onChange={(e) => setBudget(e.target.value)}
            />

            {/* AGENT SELECT */}
            <select
              value={agent}
              onChange={(e) => setAgent(e.target.value)}
              className="p-2 rounded bg-[#111122] border border-gray-700 text-white"
            >
              <option>Agent A</option>
              <option>Agent B</option>
            </select>

            <button
              onClick={addLead}
              className="bg-purple-600 px-5 py-2 rounded-lg hover:scale-105 transition"
            >
              Add Lead
            </button>
          </div>
        </motion.div>

        {/* LEADS LIST */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {myLeads.map((lead) => (
            <motion.div
              key={lead.id}
              whileHover={{ scale: 1.03 }}
              className="bg-[#1a1a2e] p-5 rounded-xl border border-gray-800"
            >
              <h3 className="text-lg font-semibold">{lead.name}</h3>

              <p className="text-gray-400">₹{lead.budget}</p>

              <p
                className={`mt-2 font-semibold ${
                  lead.score === "High"
                    ? "text-green-400"
                    : lead.score === "Medium"
                    ? "text-yellow-400"
                    : "text-red-400"
                }`}
              >
                {lead.score} Priority
              </p>

              <p className="text-sm text-gray-500 mt-1">
                Assigned to: {lead.agent}
              </p>

              <p className="text-xs text-purple-400 mt-2">
                Status: {lead.status}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default Leads;