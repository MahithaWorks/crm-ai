import Sidebar from "../components/Sidebar";
import { useState } from "react";
import { motion } from "framer-motion";
import { leadsData, updateLeads, addHistory } from "../data/store";

function Pipeline() {
  const stages = ["New", "Contacted", "Visit Scheduled", "Closed"];
  const [, setRefresh] = useState(false);

  const moveLead = (id) => {
    const updated = leadsData.map((lead) => {
      if (lead.id === id) {
        const currentStage = stages.indexOf(lead.status);

        if (currentStage < stages.length - 1) {
          const newStatus = stages[currentStage + 1];

          addHistory({
            leadId: lead.id,
            name: lead.name,
            from: lead.status,
            to: newStatus,
            time: new Date().toLocaleString(),
            agent: lead.agent,
            budget: lead.budget,
          });

          return { ...lead, status: newStatus };
        }
      }
      return lead;
    });

    updateLeads(updated);
    setRefresh((p) => !p);
  };

  return (
    <div className="flex">
      <Sidebar />

      <div className="p-8 w-full">
        <h1 className="text-3xl mb-6 font-bold">Pipeline</h1>

        <div className="grid grid-cols-4 gap-6">
          {stages.map((stage) => (
            <div key={stage} className="bg-[#1a1a2e] p-4 rounded-xl">
              <h3 className="text-purple-400 mb-4">{stage}</h3>

              {leadsData
                .filter(
                  (lead) =>
                    lead.status === stage && !lead.completed // ✅ FIXED
                )
                .map((lead) => (
                  <motion.div
                    key={lead.id}
                    whileHover={{ scale: 1.05 }}
                    className="bg-[#111122] p-3 rounded mb-2 cursor-pointer"
                    onClick={() => moveLead(lead.id)}
                  >
                    <p className="font-semibold">{lead.name}</p>
                    <p className="text-sm text-gray-400">₹{lead.budget}</p>
                    <p className="text-xs text-gray-500">{lead.agent}</p>
                  </motion.div>
                ))}
            </div>
          ))}
        </div>

        <p className="mt-6 text-gray-500">
          👉 Click a lead to move it to next stage
        </p>
      </div>
    </div>
  );
}

export default Pipeline;