import { useState } from "react";

function Login() {
  const [isRegister, setIsRegister] = useState(false);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const getUsers = () => {
    return JSON.parse(localStorage.getItem("users")) || [];
  };

  const saveUsers = (users) => {
    localStorage.setItem("users", JSON.stringify(users));
  };

  const handleSubmit = () => {
    if (!username || !password) {
      alert("Enter username & password");
      return;
    }

    const users = getUsers();

    if (isRegister) {
      const exists = users.find((u) => u.username === username);

      if (exists) {
        alert("User already exists! Please login.");
        return;
      }

      const newUsers = [...users, { username, password }];
      saveUsers(newUsers);

      alert("Registered successfully! Now login.");
      setIsRegister(false);
    } else {
      const user = users.find(
        (u) => u.username === username && u.password === password
      );

      if (!user) {
        alert("Invalid credentials ❌");
        return;
      }

      // ✅ Save logged-in user
      localStorage.setItem("loggedInUser", JSON.stringify(user));

      // 🔥 IMPORTANT FIX (reload app so store loads correct user data)
      window.location.href = "/dashboard";
    }
  };

  return (
    <div className="h-screen flex items-center justify-center bg-[#0f0f1a] text-white">
      <div className="bg-[#1a1a2e] p-8 rounded-xl w-[300px] shadow-lg">
        <h2 className="text-2xl mb-6 text-center">
          {isRegister ? "Register" : "Login"}
        </h2>

        <input
          className="w-full p-2 mb-4 rounded bg-[#111122] border border-gray-700"
          placeholder="Username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />

        <input
          type="password"
          className="w-full p-2 mb-4 rounded bg-[#111122] border border-gray-700"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />

        <button
          onClick={handleSubmit}
          className="w-full bg-purple-600 py-2 rounded hover:scale-105 transition"
        >
          {isRegister ? "Register" : "Login"}
        </button>

        <p
          className="mt-4 text-sm text-center cursor-pointer text-purple-400"
          onClick={() => setIsRegister(!isRegister)}
        >
          {isRegister
            ? "Already have an account? Login"
            : "New user? Register"}
        </p>
      </div>
    </div>
  );
}

export default Login;