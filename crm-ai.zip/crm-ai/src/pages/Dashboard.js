import Sidebar from "../components/Sidebar";
import { leadsData } from "../data/store";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

function Dashboard() {
  const user = JSON.parse(localStorage.getItem("loggedInUser"));

  const myLeads = leadsData.filter(
    (l) => l.owner === user?.username
  );

  const total = myLeads.length;
  const high = myLeads.filter((l) => l.score === "High").length;
  const medium = myLeads.filter((l) => l.score === "Medium").length;
  const low = myLeads.filter((l) => l.score === "Low").length;

  const chartData = [
    { name: "High", value: high },
    { name: "Medium", value: medium },
    { name: "Low", value: low },
  ];

  // 🔥 Agent stats
  const agentStats = {};
  myLeads.forEach((lead) => {
    if (!agentStats[lead.agent]) {
      agentStats[lead.agent] = { total: 0, closed: 0 };
    }
    agentStats[lead.agent].total++;
    if (lead.status === "Closed") {
      agentStats[lead.agent].closed++;
    }
  });

  const agentChartData = Object.keys(agentStats).map((agent) => ({
    name: agent,
    value: agentStats[agent].closed,
  }));

  let topAgent = null;
  let maxClosed = 0;

  Object.entries(agentStats).forEach(([agent, data]) => {
    if (data.closed > maxClosed) {
      maxClosed = data.closed;
      topAgent = agent;
    }
  });

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar />

      <div className="p-6 w-full overflow-hidden">
        {/* HEADER */}
        <h1 className="text-2xl font-bold mb-4">
          Welcome, {user?.username} 👋
        </h1>

        {/* CARDS */}
        <div className="grid grid-cols-4 gap-4 mb-4">
          {[{label:"Total",value:total},{label:"High",value:high},{label:"Medium",value:medium},{label:"Low",value:low}].map((card, i) => (
            <div key={i} className="bg-[#1a1a2e] p-4 rounded-xl">
              <p className="text-gray-400 text-sm">{card.label}</p>
              <p className="text-xl font-bold text-purple-400">{card.value}</p>
            </div>
          ))}
        </div>

        {/* CHARTS */}
        <div className="grid grid-cols-2 gap-4 mb-4">

          {/* Lead Distribution */}
          <div className="bg-[#1a1a2e] p-4 rounded-xl h-[220px]">
            <h2 className="text-sm mb-2 text-purple-300">
              Lead Distribution
            </h2>

            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <XAxis dataKey="name" stroke="#aaa" />
                <YAxis stroke="#aaa" />
                <Tooltip />
                <Bar dataKey="value" fill="#7c3aed" />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Agent Performance */}
          <div className="bg-[#1a1a2e] p-4 rounded-xl h-[220px]">
            <h2 className="text-sm mb-2 text-purple-300">
              Agent Performance
            </h2>

            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={agentChartData}>
                <XAxis dataKey="name" stroke="#aaa" />
                <YAxis stroke="#aaa" />
                <Tooltip />
                <Bar dataKey="value" fill="#22c55e" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* BOTTOM */}
        <div className="grid grid-cols-2 gap-4">

          {/* Top Agent */}
          <div className="bg-[#1a1a2e] p-4 rounded-xl border border-purple-500">
            <h2 className="text-sm text-purple-300 mb-2">
              🏆 Top Agent
            </h2>

            {topAgent ? (
              <p>
                {topAgent} →{" "}
                <span className="text-green-400">
                  {maxClosed} deals
                </span>
              </p>
            ) : (
              <p className="text-gray-400">No data</p>
            )}
          </div>

          {/* AI Insights */}
          <div className="bg-[#1a1a2e] p-4 rounded-xl">
            <h2 className="text-sm text-purple-300 mb-2">
              AI Insights
            </h2>

            <p className="text-xs">
              {high > 0
                ? "🔥 Focus on high-value leads."
                : "No high-value leads."}
            </p>

            <p className="text-xs">
              {total > 5
                ? "⚡ Many leads — act fast."
                : "Manageable workload."}
            </p>

            <p className="text-xs">
              {low > high
                ? "⚠️ Too many low leads."
                : "Good lead quality."}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;