import Sidebar from "../components/Sidebar";
import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import {
  leadsData,
  visitsData,
  addVisitToStore,
  updateVisits,
  updateLeads,
} from "../data/store";

function Visits() {
  const [, setRefresh] = useState(false);

  const [selectedLead, setSelectedLead] = useState("");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [reminder, setReminder] = useState(false);

  const [activeReminder, setActiveReminder] = useState(null);

  const today = new Date().toISOString().split("T")[0];

  const addVisit = () => {
    if (!selectedLead || !date || !time) return;

    const lead = leadsData.find((l) => l.name === selectedLead);

    // ❌ Prevent duplicate visit for same lead
    const exists = visitsData.find((v) => v.leadId === lead?.id);
    if (exists) {
      alert("⚠️ This lead already has a scheduled visit!");
      return;
    }

    const newVisit = {
      id: Date.now(),
      leadId: lead?.id,
      name: selectedLead,
      date,
      time,
      reminder,
      notified: false,
    };

    addVisitToStore(newVisit);
    setRefresh((p) => !p);

    setSelectedLead("");
    setDate("");
    setTime("");
    setReminder(false);
  };

  // 🔔 Reminder + Auto remove after time
  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date();

      let updatedVisits = visitsData.map((visit) => {
        const visitTime = new Date(`${visit.date}T${visit.time}`);

        // 🔔 Show popup
        if (visit.reminder && !visit.notified && now >= visitTime) {
          setActiveReminder(`🔔 Visit with ${visit.name} now!`);
          setTimeout(() => setActiveReminder(null), 3000);

          return { ...visit, notified: true };
        }

        return visit;
      });

      // 🔥 Remove expired visits + mark completed
      updatedVisits = updatedVisits.filter((visit) => {
        const visitTime = new Date(`${visit.date}T${visit.time}`);

        if (visitTime <= now) {
          const updatedLeads = leadsData.map((l) => {
            if (l.id === visit.leadId) {
              return { ...l, completed: true };
            }
            return l;
          });

          updateLeads(updatedLeads);
          return false;
        }

        return true;
      });

      updateVisits(updatedVisits);
      setRefresh((p) => !p);
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex">
      <Sidebar />

      <div className="p-8 w-full">
        <h1 className="text-3xl mb-6 font-bold">Visit Scheduler</h1>

        {/* 🔔 Floating Reminder */}
        {activeReminder && (
          <div className="fixed top-5 right-5 bg-purple-600 px-5 py-3 rounded-lg shadow-lg animate-pulse z-50 text-white">
            {activeReminder}
          </div>
        )}

        {/* FORM */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-[#1a1a2e] p-6 rounded-xl mb-6 shadow-lg"
        >
          <h2 className="mb-4 text-purple-300">Schedule Visit</h2>

          <div className="flex gap-4 flex-wrap items-center">

            {/* SELECT LEAD */}
            <select
              className="p-2 rounded bg-[#111122] border border-gray-700 text-white"
              value={selectedLead}
              onChange={(e) => setSelectedLead(e.target.value)}
            >
              <option value="">Select Lead</option>
              {leadsData.map((lead) => (
                <option key={lead.id} value={lead.name}>
                  {lead.name}
                </option>
              ))}
            </select>

            {/* DATE (WHITE ICON FIXED) */}
            <input
              type="date"
              min={today}
              className="p-2 rounded bg-[#111122] border border-gray-700 text-white appearance-none"
              style={{ colorScheme: "dark" }}
              value={date}
              onChange={(e) => setDate(e.target.value)}
            />

            {/* TIME (WHITE ICON FIXED) */}
            <input
              type="time"
              className="p-2 rounded bg-[#111122] border border-gray-700 text-white appearance-none"
              style={{ colorScheme: "dark" }}
              value={time}
              onChange={(e) => setTime(e.target.value)}
            />

            {/* 🔔 REMINDER BUTTON */}
            <button
              onClick={() => setReminder(!reminder)}
              className={`px-3 py-2 rounded ${
                reminder ? "bg-purple-600" : "bg-gray-700"
              }`}
            >
              🔔
            </button>

            <button
              onClick={addVisit}
              className="bg-purple-600 px-5 py-2 rounded-lg hover:scale-105 transition"
            >
              Schedule
            </button>
          </div>
        </motion.div>

        {/* VISITS LIST */}
        <div className="grid gap-4">
          {visitsData.map((v) => (
            <motion.div
              key={v.id}
              whileHover={{ scale: 1.02 }}
              className="bg-[#1a1a2e] p-4 rounded-xl border border-gray-800"
            >
              <p className="font-semibold">{v.name}</p>

              <p className="text-gray-400">
                📅 {v.date} | ⏰ {v.time}
              </p>

              {v.reminder && (
                <p className="text-purple-400 text-sm mt-1">
                  🔔 Reminder Enabled
                </p>
              )}
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default Visits;