const getUser = () => {
  return JSON.parse(localStorage.getItem("loggedInUser"));
};

const getKey = () => {
  const user = getUser();
  return user?.username || "guest";
};

// 🔥 LOAD DATA PER USER
const loadData = () => {
  const key = getKey();

  return {
    leads: JSON.parse(localStorage.getItem(`leads_${key}`)) || [],
    visits: JSON.parse(localStorage.getItem(`visits_${key}`)) || [],
    history: JSON.parse(localStorage.getItem(`history_${key}`)) || [],
  };
};

// 🔥 SAVE DATA PER USER
const saveData = (leads, visits, history) => {
  const key = getKey();

  localStorage.setItem(`leads_${key}`, JSON.stringify(leads));
  localStorage.setItem(`visits_${key}`, JSON.stringify(visits));
  localStorage.setItem(`history_${key}`, JSON.stringify(history));
};

let { leads: leadsData, visits: visitsData, history: historyData } = loadData();

// ===== LEADS =====
export { leadsData };

export const addLeadToStore = (lead) => {
  leadsData.push(lead);
  saveData(leadsData, visitsData, historyData);
};

export const updateLeads = (updated) => {
  leadsData = updated;
  saveData(leadsData, visitsData, historyData);
};

// ===== VISITS =====
export { visitsData };

export const addVisitToStore = (visit) => {
  visitsData.push(visit);
  saveData(leadsData, visitsData, historyData);
};

export const updateVisits = (updated) => {
  visitsData = updated;
  saveData(leadsData, visitsData, historyData);
};

// ===== HISTORY =====
export const addHistory = (entry) => {
  historyData.push(entry);
  saveData(leadsData, visitsData, historyData);
};