import { Link, useLocation } from "react-router-dom";

function Sidebar() {
  const location = useLocation();

  const handleLogout = () => {
    localStorage.removeItem("loggedInUser");
    window.location.href = "/";
  };

  const navItem = (path, name) => (
    <Link
      to={path}
      className={`block px-4 py-2 rounded-lg transition ${
        location.pathname === path
          ? "bg-purple-600 text-white"
          : "text-gray-300 hover:bg-[#1a1a2e]"
      }`}
    >
      {name}
    </Link>
  );

  return (
    <div className="w-60 h-screen bg-[#0f0f1a] p-6 flex flex-col">
      
      {/* LOGO */}
      <h1 className="text-2xl font-bold text-purple-400 mb-10">
        CRM AI
      </h1>

      {/* NAV */}
      <div className="flex flex-col gap-4">
        {navItem("/dashboard", "Dashboard")}
        {navItem("/leads", "Leads")}
        {navItem("/pipeline", "Pipeline")}
        {navItem("/visits", "Visits")}
      </div>

      {/* LOGOUT */}
      <div className="mt-auto">
        <button
          onClick={handleLogout}
          className="w-full bg-red-500 py-2 rounded-lg hover:scale-105 transition"
        >
          Logout
        </button>
      </div>
    </div>
  );
}

export default Sidebar;